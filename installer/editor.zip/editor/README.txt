The editor is in the "dirt" folder | editor.exe

